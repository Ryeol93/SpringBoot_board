package com.example.ex00.dependency.qulifier;

public interface Restaurant {
    public int getSteakPrice();
    
    public boolean getSidebar();
}
