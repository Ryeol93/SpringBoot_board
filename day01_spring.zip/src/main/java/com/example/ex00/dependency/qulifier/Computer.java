package com.example.ex00.dependency.qulifier;

public interface Computer {
    public int getScreenWidth();
}
