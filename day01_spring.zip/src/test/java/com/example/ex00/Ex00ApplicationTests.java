package com.example.ex00;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex00ApplicationTests {

    @Test
    void contextLoads() {
    }

}
